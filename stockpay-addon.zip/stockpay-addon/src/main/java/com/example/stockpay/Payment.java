package com.example.stockpay;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public class Payment {
    /** Removes {@code total} currency items from the player. Returns false (and takes nothing) if they can't pay. */
    public static boolean tryCharge(Player player, int total) {
        if (total <= 0 || player.isCreative()) return true;

        var inv = player.getInventory();
        var currency = StockPayConfig.currency();

        int have = 0;
        for (ItemStack s : inv.items) if (s.is(currency)) have += s.getCount();
        if (have < total) return false;

        int remaining = total;
        for (ItemStack s : inv.items) {
            if (remaining <= 0) break;
            if (s.is(currency)) {
                int take = Math.min(remaining, s.getCount());
                s.shrink(take);
                remaining -= take;
            }
        }
        inv.setChanged();
        return true;
    }
}
