package com.example.stockpay;

import net.minecraft.world.item.ItemStack;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

/**
 * Reads Create's order/cart objects reflectively so this addon doesn't need Create on the compile classpath.
 * VERIFY field/method names against Create's decompiled sources (./gradlew genSources + browse the jar).
 */
public class OrderMath {
    private static boolean warned = false;

    /** Total price of a list of BigItemStack (public fields "stack" and "count"). Returns -1 if unreadable. */
    public static int totalOf(List<?> bigStacks) {
        try {
            int total = 0;
            for (Object big : bigStacks) {
                ItemStack stack = (ItemStack) big.getClass().getField("stack").get(big);
                int count = big.getClass().getField("count").getInt(big);
                total += StockPayConfig.priceOf(stack) * count;
            }
            return total;
        } catch (ReflectiveOperationException | ClassCastException e) {
            warn("Could not read BigItemStack fields: " + e);
            return -1;
        }
    }

    /** Reads a (possibly private) field by name from any object. */
    public static Object field(Object target, String name) throws ReflectiveOperationException {
        Class<?> c = target.getClass();
        while (c != null) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f.get(target);
            } catch (NoSuchFieldException ignored) {
                c = c.getSuperclass();
            }
        }
        throw new NoSuchFieldException(name);
    }

    /** From the order packet: packet.order -> order.stacks() -> total. Returns -1 if unreadable. */
    public static int totalFromPacket(Object packet) {
        try {
            Object order = field(packet, "order");           // VERIFY field name
            Method m = order.getClass().getMethod("stacks"); // VERIFY accessor name
            return totalOf((List<?>) m.invoke(order));
        } catch (ReflectiveOperationException | ClassCastException e) {
            warn("Could not read order from packet: " + e);
            return -1;
        }
    }

    private static void warn(String msg) {
        if (!warned) {
            warned = true;
            System.err.println("[stockpay] " + msg + " (further errors suppressed)");
        }
    }
}
