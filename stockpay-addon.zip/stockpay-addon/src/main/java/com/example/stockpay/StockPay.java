package com.example.stockpay;

import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;

@Mod(StockPay.MOD_ID)
public class StockPay {
    public static final String MOD_ID = "stockpay";

    public StockPay(ModContainer container) {
        container.registerConfig(ModConfig.Type.SERVER, StockPayConfig.SPEC);
    }
}
