package com.example.stockpay;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.common.ModConfigSpec;

import java.util.List;

public class StockPayConfig {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.ConfigValue<String> CURRENCY;
    public static final ModConfigSpec.ConfigValue<List<? extends String>> PRICES;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();
        CURRENCY = b.comment("Item used as payment (registry id).")
                .define("currency", "minecraft:emerald");
        PRICES = b.comment("Entries: modid:item=price, price is in currency items per 1 item.")
                .defineList("prices",
                        List.of("minecraft:iron_ingot=1", "create:brass_ingot=2"),
                        o -> o instanceof String s && s.contains("="));
        SPEC = b.build();
    }

    public static Item currency() {
        return BuiltInRegistries.ITEM.get(ResourceLocation.parse(CURRENCY.get()));
    }

    /** Price for a single item. 0 means free / not priced. */
    public static int priceOf(ItemStack stack) {
        String id = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
        try {
            for (String e : PRICES.get()) {
                String[] p = e.split("=", 2);
                if (p[0].trim().equals(id)) return Math.max(0, Integer.parseInt(p[1].trim()));
            }
        } catch (IllegalStateException | NumberFormatException ignored) {
            // config not loaded yet, or a malformed entry
        }
        return 0;
    }
}
