package com.example.stockpay.mixin;

import com.example.stockpay.OrderMath;
import com.example.stockpay.Payment;
import com.example.stockpay.StockPayConfig;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Server-side payment enforcement.
 * VERIFY: target class and the "handle" signature against Create 6.0 sources.
 */
@Mixin(targets = "com.simibubi.create.content.logistics.stockTicker.PackageOrderRequestPacket")
public class PackageOrderPacketMixin {

    @Inject(method = "handle", at = @At("HEAD"), cancellable = true)
    private void stockpay$charge(ServerPlayer player, CallbackInfo ci) {
        int total = OrderMath.totalFromPacket(this);
        if (total <= 0) return; // free, or unreadable (logged once)

        if (!Payment.tryCharge(player, total)) {
            String name = StockPayConfig.currency().getDescription().getString();
            player.displayClientMessage(
                    Component.literal("Not enough " + name + " (need " + total + ")"), true);
            ci.cancel();
        }
    }
}
