package com.example.stockpay.mixin;

import com.example.stockpay.OrderMath;
import com.example.stockpay.StockPayConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * Draws the cart total on the Stock Keeper screen.
 * VERIFY: target class, "render" signature, and the cart field name ("itemsToOrder").
 */
@Mixin(targets = "com.simibubi.create.content.logistics.stockTicker.StockKeeperRequestScreen")
public abstract class StockKeeperScreenMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void stockpay$renderTotal(GuiGraphics g, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        try {
            List<?> cart = (List<?>) OrderMath.field(this, "itemsToOrder"); // VERIFY
            int total = OrderMath.totalOf(cart);
            if (total < 0) return;

            Screen self = (Screen) (Object) this;
            String text = "Total: " + total + " x "
                    + StockPayConfig.currency().getDescription().getString();
            g.drawString(Minecraft.getInstance().font, text, 8, self.height - 16, 0xFFD700);
        } catch (ReflectiveOperationException | ClassCastException ignored) {
            // wrong field name for this Create version; fail quietly
        }
    }
}
