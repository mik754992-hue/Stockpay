package com.example.stockpay.client;

import com.example.stockpay.StockPay;
import com.example.stockpay.StockPayConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

/** Adds "Price: N" to item tooltips, only while the Stock Keeper screen is open. */
@EventBusSubscriber(modid = StockPay.MOD_ID, value = Dist.CLIENT)
public class PriceTooltips {
    private static final String SCREEN =
            "com.simibubi.create.content.logistics.stockTicker.StockKeeperRequestScreen"; // VERIFY

    @SubscribeEvent
    public static void onTooltip(ItemTooltipEvent e) {
        var screen = Minecraft.getInstance().screen;
        if (screen == null || !screen.getClass().getName().equals(SCREEN)) return;

        int price = StockPayConfig.priceOf(e.getItemStack());
        if (price > 0) {
            String cur = StockPayConfig.currency().getDescription().getString();
            e.getToolTip().add(Component.literal("Price: " + price + " " + cur)
                    .withStyle(ChatFormatting.GOLD));
        }
    }
}
