package net.mcreator.yourmod;   // CHANGE to your MCreator mod's package

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

/**
 * MCreator "Custom element" version: DISPLAY ONLY (prices + cart total). No payment enforcement:
 * that needs the Mixin project in the repo root.
 * Edit PRICES below. Verify SCREEN_CLASS and the cart field name against Create's sources.
 */
@EventBusSubscriber(value = Dist.CLIENT)
public class StockTickerPriceOverlay {
    private static final Map<String, Integer> PRICES = Map.of(
            "minecraft:iron_ingot", 1,
            "create:brass_ingot", 2);
    private static final String CURRENCY_NAME = "Emerald";

    private static final String SCREEN_CLASS =
            "com.simibubi.create.content.logistics.stockTicker.StockKeeperRequestScreen";
    private static Field cartField;

    private static int priceOf(ItemStack s) {
        return PRICES.getOrDefault(BuiltInRegistries.ITEM.getKey(s.getItem()).toString(), 0);
    }

    @SubscribeEvent
    public static void onRender(ScreenEvent.Render.Post e) {
        var screen = e.getScreen();
        if (!screen.getClass().getName().equals(SCREEN_CLASS)) return;
        try {
            if (cartField == null) {
                cartField = screen.getClass().getDeclaredField("itemsToOrder"); // VERIFY
                cartField.setAccessible(true);
            }
            int total = 0;
            for (Object big : (List<?>) cartField.get(screen)) {
                ItemStack stack = (ItemStack) big.getClass().getField("stack").get(big);
                total += priceOf(stack) * big.getClass().getField("count").getInt(big);
            }
            e.getGuiGraphics().drawString(Minecraft.getInstance().font,
                    "Total: " + total + " x " + CURRENCY_NAME, 8, screen.height - 16, 0xFFD700);
        } catch (Exception ex) {
            // field names differ in this Create version; fail quietly
        }
    }

    @SubscribeEvent
    public static void onTooltip(ItemTooltipEvent e) {
        var screen = Minecraft.getInstance().screen;
        if (screen == null || !screen.getClass().getName().equals(SCREEN_CLASS)) return;
        int price = priceOf(e.getItemStack());
        if (price > 0) e.getToolTip().add(Component.literal("Price: " + price + " " + CURRENCY_NAME)
                .withStyle(ChatFormatting.GOLD));
    }
}
