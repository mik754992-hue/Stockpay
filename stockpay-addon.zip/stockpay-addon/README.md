# Stock Ticker Pay

A Create addon that puts **prices and payment** on the Stock Ticker / Stock Keeper UI instead of using a tablecloth.

- Targets: Minecraft 1.21.1, NeoForge 21.1.x, Create 6.0.x
- Prices and the currency item are set in the server config (`stockpay-server.toml`):
  ```toml
  currency = "minecraft:emerald"
  prices = ["minecraft:iron_ingot=1", "create:brass_ingot=2"]
  ```
- Client: shows the cart total on the Stock Keeper screen and a price line in item tooltips.
- Server: a Mixin on Create's order packet charges the player's inventory and cancels the order if they can't pay (creative players pay nothing).

## STATUS: untested scaffold

This was written without Create's source in front of me and has **not been compiled or run**. These names are from memory and must be checked against Create's decompiled jar:

| Where | What to verify |
|---|---|
| `mixin/PackageOrderPacketMixin` | target class `PackageOrderRequestPacket`, method `handle` and its parameters |
| `OrderMath.totalFromPacket` | packet field `order`, accessor `stacks()` |
| `mixin/StockKeeperScreenMixin`, `client/PriceTooltips` | screen class `StockKeeperRequestScreen`, `render` signature, cart field `itemsToOrder` |
| `build.gradle` / `gradle.properties` | Create maven coordinates and version, plus Create's own runtime deps (Ponder, Flywheel, Registrate) |

A wrong Mixin target or signature crashes on launch (the mixin config is `required`). A wrong reflective field name just logs once and skips the feature. For a quick way to check names, temporarily add Create as a dev dependency and inspect the sources with your IDE.

## Build

No Gradle wrapper is included. Either generate one, or just use an installed Gradle 8.10+:

```
gradle wrapper --gradle-version 8.10.2
./gradlew build          # jar in build/libs
./gradlew runClient
```

## Known gaps

- Frogports and Redstone Requesters use other code paths and bypass payment until hooked.
- Coins are deleted, not paid to the shop owner. Paying the Stock Ticker's owner needs their UUID from the block entity.
- Prices are global, not per shop.

## MCreator

Mixins can't be added from inside MCreator, so the full project here is a normal Gradle mod. Two ways to use MCreator alongside it:

1. **Coin item**: make your currency item in MCreator, then set `currency` in the config to its id.
2. **Display only**: `mcreator/net/mcreator/yourmod/StockTickerPriceOverlay.java` is a self-contained custom element (Add mod element → Custom element, or drop the file into your workspace's `src/main/java`). It shows prices and the total but does **not** enforce payment.

## License

MIT
